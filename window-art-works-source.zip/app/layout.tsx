import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Window Art Works",
  description: "Explore seasonal window art, preview it on your storefront, and request a quote.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}

