import { env } from 'cloudflare:workers';
export async function POST(request:Request){
 try {
  if(request.headers.get('origin')!==new URL(request.url).origin) return Response.json({error:'Invalid request origin.'},{status:403});
  if(Number(request.headers.get('content-length')||0)>18000000) return Response.json({error:'Please use files smaller than 15 MB combined.'},{status:413});
  const form=await request.formData();
  const fields=['name','email','business','location','date','windows','dimensions','design','greeting','notes'];
  const data:Record<string,string>={};
  for(const field of fields) data[field]=String(form.get(field)||'').trim().slice(0,3000);
  if(!data.name||!/^\S+@\S+\.\S+$/.test(data.email)||!data.location) return Response.json({error:'Please enter your name, valid email, and service location.'},{status:400});
  const files=form.getAll('photos').filter((f):f is File=>f instanceof File&&f.size>0);
  if(files.length>5||files.reduce((n,f)=>n+f.size,0)>15000000||files.some(f=>!['image/jpeg','image/png','image/webp'].includes(f.type))) return Response.json({error:'Upload up to 5 JPG, PNG, or WebP photos, 15 MB total.'},{status:400});
  const bucket=(env as unknown as {BUCKET:R2Bucket}).BUCKET;
  if(!bucket) return Response.json({error:'Quote storage is unavailable. Please try again later.'},{status:503});
  const id=crypto.randomUUID(); const prefix='quotes/'+id+'/'; const keys:string[]=[];
  try {
   for(let i=0;i<files.length;i++){const key=prefix+'window-'+i; await bucket.put(key,await files[i].arrayBuffer(),{httpMetadata:{contentType:files[i].type}});keys.push(key)}
   await bucket.put(prefix+'request.json',JSON.stringify({id,createdAt:new Date().toISOString(),...data,photos:keys}),{httpMetadata:{contentType:'application/json'}});
  }catch(e){await Promise.all(keys.map(key=>bucket.delete(key)));throw e}
  return Response.json({id},{status:201,headers:{'Cache-Control':'no-store'}});
 }catch{return Response.json({error:'We could not save your request. Please try again.'},{status:500})}
}
