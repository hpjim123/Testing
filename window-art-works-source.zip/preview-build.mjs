import {build} from './node_modules/.pnpm/rolldown@1.0.1/node_modules/rolldown/dist/index.mjs';
import fs from 'node:fs';
fs.mkdirSync('.sites-runtime/local-preview',{recursive:true});
fs.writeFileSync('.sites-runtime/preview-entry.tsx',`import React from 'react';import {createRoot} from 'react-dom/client';import Home from '../app/page';createRoot(document.getElementById('root')!).render(<Home/>);`);
await build({input:'./.sites-runtime/preview-entry.tsx',output:{file:'.sites-runtime/local-preview/app.js',format:'iife',minify:true},transform:{define:{'process.env.NODE_ENV':JSON.stringify('production')},jsx:{runtime:'automatic'}}});
const css=fs.readFileSync('app/globals.css','utf8').replace(/^@import.*$/gm,'');
const js=fs.readFileSync('.sites-runtime/local-preview/app.js','utf8');
fs.writeFileSync('.sites-runtime/local-preview/index.html',`<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Window Art Works</title><style>${css}</style><div id="root"></div><script>${js.replace(/<\/script/gi,'<\\/script')}</script></html>`);
console.log('Local browser preview prepared.');


